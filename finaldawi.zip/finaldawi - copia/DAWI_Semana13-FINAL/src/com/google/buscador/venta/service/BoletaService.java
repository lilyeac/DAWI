package com.google.buscador.venta.service;

import java.util.List;

import com.google.buscador.venta.bean.BoletaBean;
import com.google.buscador.venta.bean.ClienteBean;
import com.google.buscador.venta.bean.ProductoBean;


public interface BoletaService {


	public abstract int insertaBoleta(BoletaBean boleta) throws Exception;
	public abstract List<ClienteBean> listaClienteTodos() throws Exception;
	public abstract List<ProductoBean> listaProductoTodos() throws Exception;
	
	
}
