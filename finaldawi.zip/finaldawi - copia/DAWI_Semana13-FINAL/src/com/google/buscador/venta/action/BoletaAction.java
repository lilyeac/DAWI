package com.google.buscador.venta.action;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import com.google.buscador.venta.bean.BoletaBean;
import com.google.buscador.venta.bean.DetalleBoletaBean;
import com.google.buscador.venta.bean.ProductoBean;
import com.google.buscador.venta.service.BoletaService;
import com.google.buscador.venta.service.BoletaServiceImpl;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@ParentPackage(value = "dawi")
public class BoletaAction extends ActionSupport {
	private String cliente;
	private String producto;
	private String cantidad;
	private String numeroBoleta;
	//sesi�n
	private Map<String, Object> sesion=ActionContext.getContext().
								getSession();
	@Action(value="/agregarSeleccion",results=@Result(name="ok",
			location="/ejemploDeBoleta.jsp"))
		public String agregarSeleccion(){
			//declarar objeto de tipo List de la clase DetalleBoletaBean
			List<DetalleBoletaBean> lista;
			//validar si existe la clave detalle
			if(sesion.get("detalle")==null)//no esiste clave "detalle"
				lista=new ArrayList<DetalleBoletaBean>();	
			else//si existe la clave "detalle"
				lista=(ArrayList<DetalleBoletaBean>)
						sesion.get("detalle");
			
			//separar el valor del atributo "producto"
			//producto==> 10,Teclado,300.0
			String sep[]=producto.split(",");
			/*
			  sep[0]=10
			  sep[1]=Teclado
			  sep[2]=300.0	
			 */
			//crear un objeto de la clase DetalleBoletaBean
			DetalleBoletaBean det=new DetalleBoletaBean();
			//setear el objeto "det"
			det.setIdProducto(Integer.parseInt(sep[0]));
			det.setNombre(sep[1]);
			det.setPrecio(Double.parseDouble(sep[2]));
			det.setCantidad(Integer.parseInt(cantidad));
			//enviar el objeto "det" al arreglo "lista"
			lista.add(det);
			//crear o actualizar la clave "detalle"
			sesion.put("detalle", lista);
			
		return "ok";
	}
	@Action(value="/registraBoleta",results=@Result(name="ok",
			location="/ejemploDeBoleta.jsp"))
		public String registraBoleta() throws Exception{
			//crear objeto de la clase BoletaBean
			BoletaBean bol=new BoletaBean();
			//setear el objeto "bol"
			bol.setIdBoleta(Integer.parseInt(numeroBoleta));
			bol.setIdCliente(Integer.parseInt(cliente));
			//recuperar clave "detalle"
			List<DetalleBoletaBean> lista;
			lista=(ArrayList<DetalleBoletaBean>)
						sesion.get("detalle");
			//enviar el objeto "lista" al arreglo que se encuentra 
			//en el objeto "bol"
			bol.setDetalles(lista);
			new BoletaServiceImpl().insertaBoleta(bol);
			return "ok";
		}
	
	public String getCliente() {
		return cliente;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	public String getProducto() {
		return producto;
	}
	public void setProducto(String producto) {
		this.producto = producto;
	}
	public String getCantidad() {
		return cantidad;
	}
	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}
	public String getNumeroBoleta() {
		return numeroBoleta;
	}
	public void setNumeroBoleta(String numeroBoleta) {
		this.numeroBoleta = numeroBoleta;
	}	

}
