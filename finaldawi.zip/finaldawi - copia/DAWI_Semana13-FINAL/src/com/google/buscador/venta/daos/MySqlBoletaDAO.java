package com.google.buscador.venta.daos;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.google.buscador.venta.bean.BoletaBean;
import com.google.buscador.venta.bean.ClienteBean;
import com.google.buscador.venta.bean.DetalleBoletaBean;
import com.google.buscador.venta.bean.ProductoBean;

public class MySqlBoletaDAO implements BoletaDAO {


	SqlSessionFactory sqlMapper = null;
	{
		String archivo = "ConfiguracionIbatis.xml";
		try {
			Reader reader = Resources.getResourceAsReader(archivo);
			sqlMapper = new SqlSessionFactoryBuilder().build(reader);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	


	
	public int insertaBoleta(BoletaBean bean) throws Exception {
		SqlSession session = sqlMapper.openSession();
		int salida = 0;
		try {
			//Para insertar la cabecera
			salida = session.insert("dawi.SQL_insertaBoletaCabecera", bean);
			
			//regresa el id generado
			int id = bean.getIdBoleta();
			
			//Se obtiene los detalles
			List<DetalleBoletaBean> detalles = bean.getDetalles();
			
			//Se insertar los detalles
			for (DetalleBoletaBean x : detalles) {
				x.setIdBoleta(id);
				System.out.println("valoresss : "+x.getIdProducto());
				salida += session.insert("dawi.SQL_insertaBoletaDetalle", x);
			}
			
			//Se envia todos los SQL
			session.commit();
			
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return salida;
	}

	


	public List<ClienteBean> traeClienteTodos() throws Exception {
		SqlSession session = sqlMapper.openSession();
		List lista = new ArrayList<ClienteBean>();
		try {
			lista =session.selectList("dawi.SQL_traeClientes");
			return lista;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}
	public List<ProductoBean> traeProductoTodos() throws Exception {
		SqlSession session = sqlMapper.openSession();
		List lista = new ArrayList<ProductoBean>();
		try {
			lista =session.selectList("dawi.SQL_traeProductos");
			return lista;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}


	
}
