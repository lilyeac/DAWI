package com.google.buscador.venta.action;

import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;


import com.google.buscador.venta.bean.ClienteBean;
import com.google.buscador.venta.bean.ProductoBean;
import com.google.buscador.venta.service.BoletaServiceImpl;
import com.opensymphony.xwork2.ActionSupport;

@ParentPackage(value = "dawi")
public class CargaComboBoxAction extends ActionSupport {
	private List<ClienteBean> listaClientes;
	private List<ProductoBean> listaProductos;

	
	@Action(value="/allClientes",results=@Result(name="ok",type="json"))
	public String allClientes() throws Exception{
		listaClientes=new BoletaServiceImpl().listaClienteTodos();
		return "ok";
	}
	@Action(value="/allProductos",results=@Result(name="ok",type="json"))
	public String allProductos() throws Exception{
		listaProductos=new BoletaServiceImpl().listaProductoTodos();
		return "ok";
	}

	public List<ClienteBean> getListaClientes() {
		return listaClientes;
	}
	public void setListaClientes(List<ClienteBean> listaClientes) {
		this.listaClientes = listaClientes;
	}
	public List<ProductoBean> getListaProductos() {
		return listaProductos;
	}
	public void setListaProductos(List<ProductoBean> listaProductos) {
		this.listaProductos = listaProductos;
	}
	
}
