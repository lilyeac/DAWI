package com.google.buscador.venta.service;

import java.util.List;

import com.google.buscador.venta.bean.BoletaBean;
import com.google.buscador.venta.bean.ClienteBean;
import com.google.buscador.venta.bean.ProductoBean;
import com.google.buscador.venta.daos.BoletaDAO;
import com.google.buscador.venta.daos.DAOFactory;

public class BoletaServiceImpl implements BoletaService{

	DAOFactory factoria = DAOFactory.getFactorty(DAOFactory.MYSQL);
	BoletaDAO dao = factoria.getBoleta();
	

	public int insertaBoleta(BoletaBean boleta) throws Exception {
		return dao.insertaBoleta(boleta);
	}

	public List<ClienteBean> listaClienteTodos() throws Exception {
		return dao.traeClienteTodos();
	}
	
	public List<ProductoBean> listaProductoTodos() throws Exception {
		return dao.traeProductoTodos();
	}

	
}
