package com.google.buscador.venta.bean;

import java.util.List;

public class BoletaBean {

	private int idBoleta;
	private String fecha;
	private int idCliente;
	private List<DetalleBoletaBean> detalles;
	public int getIdBoleta() {
		return idBoleta;
	}
	public void setIdBoleta(int idBoleta) {
		this.idBoleta = idBoleta;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public List<DetalleBoletaBean> getDetalles() {
		return detalles;
	}
	public void setDetalles(List<DetalleBoletaBean> detalles) {
		this.detalles = detalles;
	}
	
	
	
	
}
