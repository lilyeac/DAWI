package com.google.buscador.venta.daos;

import java.util.List;

import com.google.buscador.venta.bean.BoletaBean;
import com.google.buscador.venta.bean.ClienteBean;
import com.google.buscador.venta.bean.ProductoBean;


public interface BoletaDAO {
	public int insertaBoleta(BoletaBean bean) throws Exception;
	public List<ClienteBean> traeClienteTodos() throws Exception;
	public List<ProductoBean> traeProductoTodos() throws Exception;

}
